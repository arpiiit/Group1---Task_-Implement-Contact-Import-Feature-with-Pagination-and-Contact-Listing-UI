
import React, { useState, useEffect } from "react";
import axios from "axios";
import ReactPaginate from "react-paginate";

const ContactList = () => {
  const [contacts, setContacts] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [newContact, setNewContact] = useState({
    name: "",
    phoneNumber: "",
    email: "",
  });
  const [isAddingContact, setIsAddingContact] = useState(false);
  const [selectedContacts, setSelectedContacts] = useState([]);

  const perPage = 10;

  useEffect(() => {
    axios
      .get(`/api/contacts?limit=${perPage}&skip=${currentPage * perPage}`)
      .then((response) => setContacts(response.data))
      .catch((error) => console.error(error));
  }, [currentPage]);

  const handlePageClick = (data) => {
    setCurrentPage(data.selected);
  };

  const handleAddContact = () => {
    setIsAddingContact(true);
  };

  const handleSaveContact = () => {
    setContacts([...contacts, newContact]);

    
    setNewContact({ name: "", phoneNumber: "", email: "" });
    setIsAddingContact(false);
  };

  const handleCancelAddContact = () => {
    
    setNewContact({ name: "", phoneNumber: "", email: "" });
    setIsAddingContact(false);
  };

  const handleCheckboxChange = (contactId) => {
    setSelectedContacts((prevSelectedContacts) => {
      if (prevSelectedContacts.includes(contactId)) {
        return prevSelectedContacts.filter((id) => id !== contactId);
      } else {
        return [...prevSelectedContacts, contactId];
      }
    });
  };

  return (
    <div>
      <button
        style={{
          padding: "10px",
          backgroundColor: "transparent",
          color: "#007bff",
          border: "1px solid #007bff",
          float: "right",
          margin: "10px",
          borderRadius: "5px",
          cursor: "pointer",
        }}
        onClick={handleAddContact}
      >
        + import Contact
      </button>
      <div style={{ margin: "20px" }}>
        <h1>Contact List</h1>

    
        {isAddingContact && (
          <div style={{ margin: "10px" }}>
            <input
              type="text"
              placeholder="Name"
              value={newContact.name}
              onChange={(e) =>
                setNewContact({ ...newContact, name: e.target.value })
              }
              style={{ margin: "5px", padding: "10px" }}
            />
            <input
              type="text"
              placeholder="Phone Number"
              value={newContact.phoneNumber}
              onChange={(e) =>
                setNewContact({ ...newContact, phoneNumber: e.target.value })
              }
              style={{ margin: "5px", padding: "10px" }}
            />
            <input
              type="text"
              placeholder="Email"
              value={newContact.email}
              onChange={(e) =>
                setNewContact({ ...newContact, email: e.target.value })
              }
              style={{ margin: "5px", padding: "10px" }}
            />

            <button
              onClick={handleSaveContact}
              style={{ margin: "5px", padding: "6px", cursor: "pointer" }}
            >
              Save Contact
            </button>
            <button
              onClick={handleCancelAddContact}
              style={{ margin: "5px", padding: "6px", cursor: "pointer" }}
            >
              Cancel
            </button>
          </div>
        )}

  
        <div style={{ border: "1px solid black", borderRadius:'5px',height:'50rem', margin:'20px' }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: "10px",
              marginBottom: "10px",
              fontWeight: "bold",
            }}
          >
            <input type="checkbox" style={{ marginRight: "-30rem" }} />
            <div>Name</div>
            <div>Mobile Number</div>
            <div>Email Contact</div>
            <div>Source</div>
          </div>


          {contacts.map((contact, index) => (
            <div
              key={contact._id}
              style={{
                display: "flex",
                justifyContent: "space-between",
                padding: "10px",
                marginBottom: "10px",
                backgroundColor: index % 2 === 0 ? "#f2f2f2" : "#ffffff",
              }}
            >
              <input
                type="checkbox"
                checked={selectedContacts.includes(contact._id)}
                onChange={() => handleCheckboxChange(contact._id)}
                style={{
                  marginRight: "-26.5rem",
                  justifyContent: "space-between",
                }}
              />
              <div style={{ marginLeft: "-1rem" }}>{contact.name}</div>
              <div style={{ marginRight: "px" }}>{contact.phoneNumber}</div>
              <div style={{ marginRight: "20px" }}>{contact.email}</div>
              <div>API</div>
            </div>
          ))}
        </div>
        <ReactPaginate
          pageCount={Math.ceil(contacts.length / perPage)}
          pageRangeDisplayed={5}
          marginPagesDisplayed={2}
          onPageChange={handlePageClick}
          containerClassName={"pagination"}
          activeClassName={"active"}
          style={{ margin: "10px" }}
        />
      </div>
    </div>
  );
};

export default ContactList;
